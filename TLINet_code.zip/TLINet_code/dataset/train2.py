import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO
from ultralytics import RTDETR

if __name__ == '__main__':
    #-------------------------------------------------------------------------------------#
    #   虽然YOLO没有构造函数__init__(),但YOLO继承的父类Model拥有构造函数
    #   在这种情况下，当创建YOLO类的实例时，会调用父类的构造函数(如果父类构造函数没有被YOLO类显式覆盖的话)
    #   如果父类的构造函数接受参数，那么这些参数可能用于初始化YOLO实例
    #-------------------------------------------------------------------------------------#

    model = YOLO('ultralytics/cfg/models/v8/TLINet.yaml')
    # model = RTDETR('ultralytics/cfg/models/my_model/yolov8-head.yaml')
    # model.load('yolov8n.pt') # loading pretrain weights
    model.train(data='dataset/Insulator.yaml',
                cache=False,
                imgsz=640,
                epochs=200,
                batch=8,
                close_mosaic=0,
                workers=0,
                device='0',
                optimizer='Adam',  # using Adam
                resume='True', # last.pt path
                # amp=False, # close amp
                # fraction=0.2,
                project='Insulator/CGFFN+MBPTB',
                name='train',
                cos_lr=True,
                patience=50,
                lr0=0.001,
                )